<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h1>Profil Pengguna</h1>

<div class="user-list">
        <div class="user-card">
        <div class="user-info">
                <span><strong>User:</strong></span> Vian
            </div>
            <div class="user-info">
                <span><strong>Role:</strong></span>Admin
            </div>
            <div class="user-info">
                <span><strong>Email:</strong></span>VianAryasatya29@gmail.com
            </div>
            <div class="user-info">
                <span><strong>Waktu Login:</strong></span> 2025-04-24 08:40:00
            </div>
            <div class="user-info status-online">
                <span><strong>Status:</strong></span>Sudah Online
            </div>
        </div>

        
    </div>
<?= $this->endSection() ?>